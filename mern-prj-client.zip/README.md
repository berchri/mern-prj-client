# Getting Started
- run `npm run dev` in "mern-prj-server" first, to start the Development Server.
- `npm start` to start

