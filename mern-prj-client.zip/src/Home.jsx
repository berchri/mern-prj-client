import React from 'react'

function Home() {
    return (
        <div>HOME</div>
    )
}

export default Home