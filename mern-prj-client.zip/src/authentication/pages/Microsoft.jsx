import React from "react";

function Microsoft() {
    return (
        <div>coming soon...</div>
    )
}

export default Microsoft