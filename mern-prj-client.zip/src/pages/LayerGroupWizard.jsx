import React from 'react'

function LayerGroupWizard() {
    return (
        <div>Component</div>
    )
}

export default LayerGroupWizard