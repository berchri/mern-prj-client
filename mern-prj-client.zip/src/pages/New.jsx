import React from 'react'

function New() {
    return (
        <div>Component</div>
    )
}

export default New