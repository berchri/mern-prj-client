import React, { useState } from 'react'
import styles from './RoomWizard.module.css'

function DetailSection() {
    return (
        <>
            {/* <div className={'row ' + styles[ 'right-topbar' ]}></div> */}
            <div className={'row ' + styles[ 'right-main' ]}></div>
            {/* <div className={'row ' + styles[ 'right-bottombar' ]}></div> */}
        </>
    )
}

export default DetailSection