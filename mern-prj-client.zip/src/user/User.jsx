import React from 'react'

function User() {
    return (
        <div>Component</div>
    )
}

export default User